

#pragma once
#include "../inc/com.hobbywing.esc.SetThrottleSource_req.h"
#include "../inc/com.hobbywing.esc.SetThrottleSource_res.h"

#define COM_HOBBYWING_ESC_SETTHROTTLESOURCE_ID 215
#define COM_HOBBYWING_ESC_SETTHROTTLESOURCE_SIGNATURE (0xC248FAAEFE5E29AULL)


#if defined(__cplusplus) && defined(DRONECAN_CXX_WRAPPERS)
#include <canard/cxx_wrappers.h>
SERVICE_MESSAGE_CXX_IFACE(com_hobbywing_esc_SetThrottleSource, COM_HOBBYWING_ESC_SETTHROTTLESOURCE_ID, COM_HOBBYWING_ESC_SETTHROTTLESOURCE_SIGNATURE, COM_HOBBYWING_ESC_SETTHROTTLESOURCE_REQUEST_MAX_SIZE, COM_HOBBYWING_ESC_SETTHROTTLESOURCE_RESPONSE_MAX_SIZE);
#endif
