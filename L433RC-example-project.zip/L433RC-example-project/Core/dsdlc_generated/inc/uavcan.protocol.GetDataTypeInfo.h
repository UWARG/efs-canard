

#pragma once
#include "../inc/uavcan.protocol.GetDataTypeInfo_req.h"
#include "../inc/uavcan.protocol.GetDataTypeInfo_res.h"

#define UAVCAN_PROTOCOL_GETDATATYPEINFO_ID 2
#define UAVCAN_PROTOCOL_GETDATATYPEINFO_SIGNATURE (0x1B283338A7BED2D8ULL)


#if defined(__cplusplus) && defined(DRONECAN_CXX_WRAPPERS)
#include <canard/cxx_wrappers.h>
SERVICE_MESSAGE_CXX_IFACE(uavcan_protocol_GetDataTypeInfo, UAVCAN_PROTOCOL_GETDATATYPEINFO_ID, UAVCAN_PROTOCOL_GETDATATYPEINFO_SIGNATURE, UAVCAN_PROTOCOL_GETDATATYPEINFO_REQUEST_MAX_SIZE, UAVCAN_PROTOCOL_GETDATATYPEINFO_RESPONSE_MAX_SIZE);
#endif
