

#pragma once
#include "../inc/uavcan.protocol.AccessCommandShell_req.h"
#include "../inc/uavcan.protocol.AccessCommandShell_res.h"

#define UAVCAN_PROTOCOL_ACCESSCOMMANDSHELL_ID 6
#define UAVCAN_PROTOCOL_ACCESSCOMMANDSHELL_SIGNATURE (0x59276B5921C9246EULL)


#if defined(__cplusplus) && defined(DRONECAN_CXX_WRAPPERS)
#include <canard/cxx_wrappers.h>
SERVICE_MESSAGE_CXX_IFACE(uavcan_protocol_AccessCommandShell, UAVCAN_PROTOCOL_ACCESSCOMMANDSHELL_ID, UAVCAN_PROTOCOL_ACCESSCOMMANDSHELL_SIGNATURE, UAVCAN_PROTOCOL_ACCESSCOMMANDSHELL_REQUEST_MAX_SIZE, UAVCAN_PROTOCOL_ACCESSCOMMANDSHELL_RESPONSE_MAX_SIZE);
#endif
